var express = require('express');
var mongoose =require('mongoose');
var path = require('path');
var bodyParser = require('body-parser');

// Connect Mongodb
mongoose.connect("mongodb://localhost/myrestful");

// Express
var app = express();

// parse application/x-www-form-urlencoded 
app.use(bodyParser.urlencoded({ extended: false }))
 
// parse application/json 
app.use(bodyParser.json())

// Routes
app.use('/api', require('./routes/api'));

app.use('/',express.static(path.join(__dirname,'/client')));

app.use('/node_modules', express.static(path.join(__dirname, '/node_modules')))

/*app.get("/", function(req, res){
	 res.send("testing app");
});*/

// Server start
app.listen(3000);
console.log("Server working fine");
