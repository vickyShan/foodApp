// Denpendencies
var restful = require('node-restful');
var mongoose = restful.mongoose;

// Schema
var ProductSchema = new mongoose.Schema({
	productId:Number,
	productName:String,
	category:String,
	subCategory:String,
	quantity:Number,
	foodSession:String,
	createdDate:Date
});

// Return module
module.exports = restful.model('product',ProductSchema);