// Denpendencies
var restful = require('node-restful');
var mongoose = restful.mongoose;

// Schema
var OrderSchema = new mongoose.Schema({
	userId:Number,
	orderId:Number,
	tableNumber:String,
	seatNumber:String,
	noOfCust:Number,
	orderList : {
		productId:Number,
		quantity:Number,
		ratePerQty:Number,
		price:Number,
		totalPrice:Number,
	},
	orderStatus:String,
	tableStatus:String,
	createdDate:Date,
	createdBy:String
});

// Return module
module.exports = restful.model('product',OrderSchema);