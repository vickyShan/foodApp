// Denpendencies
var restful = require('node-restful');
var mongoose = restful.mongoose;

// Schema
var TableOrderInfoSchema = new mongoose.Schema({
	tableNumber:String,
	seatNumber:String,
	noOfCust:Number,
	orderId:Number,
	userId:Number,
	billAmount:Number,
	tableStatus:String,
	orderStatus:String
});

// Return module
module.exports = restful.model('product',TableOrderInfoSchema);