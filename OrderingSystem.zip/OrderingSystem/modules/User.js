// Denpendencies
var restful = require('node-restful');
var mongoose = restful.mongoose;

// Schema
var UserSchema = new mongoose.Schema({
	userId:Number,
	userName:String,
	password:String,
	role:String,
	createdDate:Date,
	createdBy:String,
	modifiedDate:Date,
	modifiedBy:String
});

// Return module
module.exports = restful.model('product',UserSchema);